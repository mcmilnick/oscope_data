function arduino_set_pin(pin_arr)

new_a = arduino;
writeDigitalPin(new_a,2,pin_arr{1});
writeDigitalPin(new_a,3,pin_arr{2});
writeDigitalPin(new_a,4,pin_arr{3});
writeDigitalPin(new_a,5,pin_arr{4});
writeDigitalPin(new_a,6,pin_arr{5});
writeDigitalPin(new_a,7,pin_arr{6});
writeDigitalPin(new_a,8,pin_arr{7});
writeDigitalPin(new_a,9,pin_arr{8});
writeDigitalPin(new_a,10,pin_arr{9});
writeDigitalPin(new_a,11,pin_arr{10});
writeDigitalPin(new_a,12,pin_arr{11});
writeDigitalPin(new_a,13,pin_arr{12});

end
