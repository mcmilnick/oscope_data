%************************************************************************
% Start GUI
%************************************************************************
% Main run occurs from gui. This must be a function to prevent infinite
% recrsion. This calls the initialization function.

function arduino_test_suite()
clear;
% Make figure based off of screen size
scrsz = get(0,'ScreenSize');
% Set figure handle, size of the gui, and keep the figure off until everything is set
test_gui = figure('Visible','off', 'Menu','none', 'Name','Test Suite',...
    'Position',[0 -(scrsz(4)/15.36) scrsz(3) scrsz(4)]);
daspect([1,1,1]);
axis off;

% Pin state title and spots for entering
uicontrol('String','Arduino Control','FontSize', 13,'Position',[(scrsz(3)/48) (scrsz(4)*.90) (scrsz(3)/11.38) 20]);
uicontrol('String','Enter Pin states','Position',[(scrsz(3)/48) (scrsz(4)*.86) (scrsz(3)/11.38) 20]);
pin_1_2_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-150) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.2');
pin_1_3_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-175) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.3');
pin_1_4_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-200) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.4');
pin_1_5_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-225) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.5');
pin_1_6_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-250) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.6');
pin_1_7_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-275) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.7');
pin_1_8_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-300) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.8');
pin_1_9_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-325) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.9');
pin_1_10_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-350) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.10');
pin_1_11_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-375) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.11');
pin_1_12_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-400) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.12');
pin_1_13_title = uicontrol('Position',[(scrsz(3)/100) (scrsz(4)-425) (scrsz(3)/30) (scrsz(4)/38.4)],'String','pin 1.13');

pin_1_2 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 150) (scrsz(3)/18) (scrsz(4)/38.4)], 'String','pin state');
pin_1_3 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 175) (scrsz(3)/18) (scrsz(4)/38.4)],'String','pin state');
pin_1_4 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 200) (scrsz(3)/18) (scrsz(4)/38.4)], 'String','pin state');
pin_1_5 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)-225) (scrsz(3)/18) (scrsz(4)/38.4)],'String','pin state');
pin_1_6 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 250) (scrsz(3)/18) (scrsz(4)/38.4)], 'String','pin state');
pin_1_7 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 275) (scrsz(3)/18) (scrsz(4)/38.4)],'String','pin state');
pin_1_8 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 300) (scrsz(3)/18) (scrsz(4)/38.4)], 'String','pin state');
pin_1_9 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)-325) (scrsz(3)/18) (scrsz(4)/38.4)],'String','pin state');
pin_1_10 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 350) (scrsz(3)/18) (scrsz(4)/38.4)], 'String','pin state');
pin_1_11 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 375) (scrsz(3)/18) (scrsz(4)/38.4)],'String','pin state');
pin_1_12 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 400) (scrsz(3)/18) (scrsz(4)/38.4)], 'String','pin state');
pin_1_13 = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/20) (scrsz(4)- 425) (scrsz(3)/18) (scrsz(4)/38.4)], 'String','pin state');

% USB capture - currently allows channel selection, time window, and time
% steps, but for further automation, scaling and triggers can be forced as
% well
uicontrol('String','USB Capture','FontSize', 13,'Position',[(scrsz(3)/48) (scrsz(4)*.43) (scrsz(3)/11.38) 20]);
capture_window = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/48) (scrsz(4)*.39) (scrsz(3)/11.38) (scrsz(4)/38.4)], 'String','capture window(s)');
sample_rate = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/48) (scrsz(4)*.36) (scrsz(3)/11.38) (scrsz(4)/38.4)], 'String','time between samples(s)');
trigger_level = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)/48) (scrsz(4)*.33) (scrsz(3)/11.38) (scrsz(4)/38.4)], 'String','Trigger level(V)');
ch1_en = uicontrol('Style','checkbox','String','CH1 enabled','Position',[(scrsz(3)/48) (scrsz(4)*.29) 130 20]);
ch2_en = uicontrol('Style','checkbox','String','CH2 enabled','Position',[(scrsz(3)/48) (scrsz(4)*.26) 130 20]);
ch3_en = uicontrol('Style','checkbox','String','CH3 enabled','Position',[(scrsz(3)/48) (scrsz(4)*.23) 130 20]);
ch4_en = uicontrol('Style','checkbox','String','CH4 enabled','Position',[(scrsz(3)/48) (scrsz(4)*.20) 130 20]);

%At any time you may reset the board
reset_but = uicontrol('Style','pushbutton', 'String','Reset', 'Position',...
    [(scrsz(3)/56.82) (scrsz(4)/22) (scrsz(3)/22.76) (scrsz(4)/30.72)],'Callback',{@reset_button_callback});

% Text for user viewing board feedback
actions_text = uicontrol('Style','text', 'FontSize', 16, 'Position',...
    [(scrsz(3)*.25) (scrsz(4)/22) (scrsz(3)/6) (scrsz(4)/26)],...
    'String','Ongoing Events');

% Initialize pins start
uicontrol('Style','pushbutton', 'String','Flash and Execute', 'Position',...
    [(scrsz(3)*.65) (scrsz(4)/22) (scrsz(3)/15) (scrsz(4)/30.72)],'Callback',{@flash_execute_callback,...
    pin_1_2,pin_1_3,pin_1_4,pin_1_5,pin_1_6,pin_1_7,pin_1_8,pin_1_9,...
    pin_1_10,pin_1_11,pin_1_12,pin_1_13, actions_text, reset_but});

% Test button
uicontrol('Style','pushbutton', 'String','Collect scope data', 'Position',...
    [(scrsz(3)*.75) (scrsz(4)/22) (scrsz(3)/15) (scrsz(4)/30.72)],'Callback',{@usb_scope_callback,...
    capture_window, sample_rate, ch1_en, ch2_en, ch3_en, ch4_en,actions_text,trigger_level,reset_but});

%Auto-analysis
uicontrol('String','Theoretical values','FontSize', 13,'Position',[(scrsz(3)*.91) (scrsz(4)*.46) (scrsz(3)/11.38) 20]);
trigger_percent = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)*.91) (scrsz(4)*.42) (scrsz(3)/12) (scrsz(4)/30.72)], 'String','Trigger ratio(decimal)');
high_voltage = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)*.91) (scrsz(4)*.38) (scrsz(3)/12) (scrsz(4)/30.72)], 'String','High voltage(V)');
rise_time = uicontrol('Style','edit', 'Position',...
    [(scrsz(3)*.91) (scrsz(4)*.34) (scrsz(3)/12) (scrsz(4)/30.72)], 'String','Rise time(ns)');
uicontrol('Style','pushbutton', 'String','Run analysis', 'Position',...
    [(scrsz(3)*.91) (scrsz(4)*.3) (scrsz(3)/12) (scrsz(4)/30.72)],'Callback',{@run_analysis_callback,...
    actions_text,high_voltage,rise_time,capture_window,trigger_percent,sample_rate,reset_but});
          
% Makes the gui visible now that it is set up.
set(test_gui, 'Visible','on')

end

% ************************************************************************
% Initialization of test suite
% ************************************************************************
function flash_execute_callback(src, ev, pin_1_2, pin_1_3,...
    pin_1_4,pin_1_5,pin_1_6,pin_1_7,pin_1_8,pin_1_9,pin_1_10,pin_1_11,...
    pin_1_12,pin_1_13, actions_text, reset_but)

% Turn off visibility from the buttons so  users can't conflict.
set(test_file_button,'Visible','off');
% Disable the names to lock them
disable_pins(pin_1_2,pin_1_3,pin_1_4,pin_1_5,pin_1_6,pin_1_7,...
    pin_1_8,pin_1_9,pin_1_10,pin_1_11,pin_1_12,pin_1_13);

% Call get the text in pin settings and then set the values
[pin_arr] = get_pin_settings(pin_1_2,pin_1_3,pin_1_4,pin_1_5,...
    pin_1_6,pin_1_7,pin_1_8,pin_1_9,pin_1_10,pin_1_11,pin_1_12,pin_1_13);
arduino_set_pin(pin_arr); %no error check on arduino pin write

% Update the state
set(actions_text, 'String', 'Flash complete');

end

%**********************************************************************
% Other callback functions
%**********************************************************************
% Resets the GUI
function reset_button_callback(src, ev)
    % Set a flag to tell execution to stop
    set(src, 'UserData', 'stop_now')
    reset_gui();
end

%Runs the script to control the Tektronix MSO4104B oscope
function usb_scope_callback(src,ev,capture_window,sample_rate,ch1_en,...
    ch2_en,ch3_en,ch4_en,actions_text,trigger_level,reset_but)
    
    ch1_on_read = get(ch1_en, 'Value');
    ch2_on_read = get(ch2_en, 'Value');
    ch3_on_read = get(ch3_en, 'Value');
    ch4_on_read = get(ch4_en, 'Value');
    set(actions_text, 'String', 'Pulling scope data');
    
    capture_win_in = str2num(get(capture_window,'String'));
    sample_rate_in = str2num(get(sample_rate,'String'));
    trig_level_in = str2num(get(trigger_level,'String'));
    
    aq_4104(ch1_on_read,ch2_on_read,ch3_on_read,ch4_on_read,capture_win_in,trig_level_in,sample_rate_in);
    set(actions_text, 'String', 'Scope scan complete');
end

%Runs the analysis suite to compare theoretical values against actual
%values. This will also make recommendations for improving the data.
function run_analysis_callback(src,ev,actions_text,high_voltage,...
    rise_time,capture_window,trigger_percent,sample_rate,reset_but)

    global ch1_wave_out;
    global ch2_wave_out;
    global ch3_wave_out;
    global ch4_wave_out;
    high_voltage_in = str2num(get(high_voltage,'String'));
    rise_time_in = str2num(get(rise_time,'String'));
    capture_win_in = str2num(get(capture_window,'String'));
    trigger_percent = str2num(get(trigger_percent,'String'));
    sample_rate_in = str2num(get(sample_rate,'String'));
    
    % Find the high trip voltage. The high trip is usually 70,80,90 percent trigger voltage  
    high_trigger = high_voltage_in * trigger_percent;
    low_trigger = high_voltage_in * (1 - trigger_percent);
    %Find the first sample which exceeds the threshold of logical high.
    first_high_sample = find((ch1_wave_out>high_trigger)==1,1,'first');
    %Find the last sample before exceeding the threshold of logical low. We
    %also specify that this must occur before the logical high.
    rise_start_sample = find((ch1_wave_out(1:first_high_sample)<low_trigger)==1,1,'last');
    ch1_true_rise_time = (first_high_sample - rise_start_sample) * sample_rate_in;
    
    first_high_sample = find((ch2_wave_out>high_trigger)==1,1,'first');
    rise_start_sample = find((ch2_wave_out<low_trigger)==1,1,'last');
    ch2_true_rise_time = (first_high_sample - rise_start_sample) * sample_rate_in;
    
    first_high_sample = find((ch3_wave_out>high_trigger)==1,1,'first');
    rise_start_sample = find((ch3_wave_out<low_trigger)==1,1,'last');
    ch3_true_rise_time = (first_high_sample - rise_start_sample) * sample_rate_in;
    
    first_high_sample = find((ch4_wave_out>high_trigger)==1,1,'first');
    rise_start_sample = find((ch4_wave_out<low_trigger)==1,1,'last');
    ch4_true_rise_time = (first_high_sample - rise_start_sample) * sample_rate_in;
end

%**********************************************************************
% Reset GUI function
%**********************************************************************
function reset_gui()
%RESET_GUI resets the gui by closing the current figure and running again.
%   While this may not seem like the proper way, merely returning to the
%   original gui requires returning and reseting. This method is however
%   flawed in the case of the figure handle being destroyed. This is the
%   safer option without spending a full week diving into the Java code
%   making the GUI and finding if a return and reset is thread safe.
    close(gcf);
    final_proj_gui();
end