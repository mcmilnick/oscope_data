# matlab notes

With matlab it is all pretty simple. I made a fun little gui for you to play with
if you want. The GUI functionality in Matlab is really not good, but what the heck,
callback functions work, it looks okay, and it takes an hour or two to make.

This one works a little different. Before grabbing the scope data, you set the
settings in the GUI. Then a graph of the data will appear. You can also run an
analysis, which is pointless in this version, but do with it what you may.

Finally, I had though maybe it would be fun to control your circuit while you aquire data.
For this reason you will see it is arduino themed. You can set Arduino pins to control your
circuit as you collect data.