function disable_pins(pin_1_2, pin_1_3, pin_1_4, pin_1_5,...
    pin_1_6,pin_1_7,pin_1_8,pin_1_9,pin_1_10,pin_1_11,pin_1_12,pin_1_13)

set(pin_1_2, 'enable', 'off')
set(pin_1_3, 'enable', 'off')
set(pin_1_4, 'enable', 'off')
set(pin_1_5, 'enable', 'off')
set(pin_1_6, 'enable', 'off')
set(pin_1_7, 'enable', 'off')
set(pin_1_8, 'enable', 'off')
set(pin_1_9, 'enable', 'off')
set(pin_1_10, 'enable', 'off')
set(pin_1_11, 'enable', 'off')
set(pin_1_12, 'enable', 'off')
set(pin_1_13, 'enable', 'off')

end
