function [board_err_code, read_in] = load_matlab_test(board_dir, test_file_button)
%LOAD_BOARD takes the user file and runs the script. For now it is matlab
% scripts only.
board_err_code = 0;
global x;
load_matlab_test = 0;
cd(board_dir);
run(test_file_button);
read_in = x;

end
