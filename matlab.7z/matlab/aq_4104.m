function aq_4104(ch1_on_read,ch2_on_read,ch3_on_read,ch4_on_read,capture_window,trigger_level,sample_rate)
myScope = oscilloscope();
availableResources = getResources(myScope);
set(myScope, 'Resource', 'USB0::0x0699::0x0409::C023588::INSTR');
connect(myScope);
set(myScope, 'Timeout', 20);
 
set(myScope, 'AcquisitionTime', sample_rate);
set(myScope, 'WaveformLength', capture_window);

%Holds at trigger
set(myScope, 'TriggerMode', 'Normal');
set(myScope, 'TriggerLevel', trigger_level);
enableChannel(myScope, {'CH1','CH2','CH3','CH4'});
setVerticalCoupling (myScope, 'CH1', 'DC');
setVerticalRange (myScope, 'CH1', 2.0);

% Acquire the waveform. 
global ch1_wave_out;
global ch2_wave_out;
global ch3_wave_out;
global ch4_wave_out;
[ch1_wave,ch2_wave,ch3_wave,ch4_wave] = getWaveform(myScope);
ch1_wave_out = ch1_wave;
ch2_wave_out = ch2_wave;
ch3_wave_out = ch3_wave;
ch4_wave_out = ch4_wave;

disconnect(myScope);
delete(myScope);
        
% Plot the waveform and assign labels for the plot.
plot(ch1_wave(1:capture_window),'Color','g')
hold on;
plot(ch2_wave(1:capture_window),'Color','r')
hold on;
plot(ch3_wave(1:capture_window),'Color','b')
hold on;
plot(ch4_wave(1:capture_window),'Color','k')
xlabel('Samples');
ylabel('Voltage');

end