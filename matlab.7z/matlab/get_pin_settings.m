function [pin_arr] = get_pin_settings(pin_1_2, pin_1_3, pin_1_4,...
    pin_1_5,pin_1_6,pin_1_7,pin_1_8,pin_1_9,pin_1_10,pin_1_11,pin_1_12,pin_1_13)

pin_arr = cell(12,1);
pin_arr{1} = get(pin_1_2, 'Value');
pin_arr{2} = get(pin_1_3, 'Value');
pin_arr{3} = get(pin_1_4, 'Value');
pin_arr{4} = get(pin_1_5, 'Value');
pin_arr{5} = get(pin_1_6, 'Value');
pin_arr{6} = get(pin_1_7, 'Value');
pin_arr{7} = get(pin_1_8, 'Value');
pin_arr{8} = get(pin_1_9, 'Value');
pin_arr{9} = get(pin_1_10, 'Value');
pin_arr{10} = get(pin_1_11, 'Value');
pin_arr{11} = get(pin_1_12, 'Value');
pin_arr{12} = get(pin_1_13, 'Value');

end
