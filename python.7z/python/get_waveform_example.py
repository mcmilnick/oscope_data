#numpy, and scilab were wheels. Pylab is technically not installed. Windows+VS workaround
import visa
import time
import numpy as np
from struct import unpack
import pylab
import visa
import scipy
import scipy.fftpack

#General test info
voltage_high_level = 1.3
trig_percent = .9 #assumes a 90/10 rise/fall scheme
high_volt_trig = voltage_high_level * trig_percent
used_to_trigger = round(high_volt_trig, 1)
low_volt_trig = voltage_high_level * (1 - trig_percent)
data_points = 20000000

#General visa manouager. Utilizes the library to find all possible connections
rm = visa.ResourceManager()
print(rm.list_resources())
#We know our resource ID already
scope = rm.open_resource('USB0::0x0699::0x0409::C023588::INSTR')
#Command for ID. See programmers guide to the scope.
print(scope.query("*IDN?"))

#Channel setup
# All commands come from the programmers guide.
scope.write("SELect:CH1 ON")
scope.write("SELect:CH2 OFF")
scope.write("SELect:CH3 OFF")
scope.write("SELect:CH4 OFF")
scope.write("SELect:CONTROl CH1")
#If multiple channels are needed
#scope.write("SELect:CONTROl {CH1|CH2}")

#Trigger setup - check pg1073 of programmers manual
scope.write("TRIGger:A:TYPe EDGE")
scope.write("TRIGger:A:EDGE:SOUrce CH1")
scope.write("TRIGger:A:LEVEL:CH1 %d" % used_to_trigger)
scope.write("TRIGger:A:EDGE:SLOpe RISE")
scope.write("TRIGger:A:MODE NORMAL")
time.sleep(3)
#Wait for trigger by checking status register
state_out = scope.query("TRIGger:STATE?").rstrip('\r\n')
state_out = state_out.rstrip('\r\n')
while (state_out != "TRIGGER"):
    time.sleep(2)
    state_out = scope.query("TRIGger:STATE?").rstrip('\r\n')
    state_out = state_out.rstrip('\r\n')
time.sleep(2)

#Triggered - take data
#Channel labels
ch1_label = scope.query("CH1:LABel?")
#Control the region displayed of whats captured on the screen
scope.write("DATA:STARt %d" % 1)
scope.write("DATA:STOP %d" % data_points)
#Control the length recorded in samples/second
scope.write("HORIZONTAL:RECORDLENGTH %d" % data_points)

#retrieve the x and y scaling along with zero points
ymult = float(scope.ask('WFMPRE:YMULT?'))
yzero = float(scope.ask('WFMPRE:YZERO?'))
yoff = float(scope.ask('WFMPRE:YOFF?'))
xincr = float(scope.ask('WFMPRE:XINCR?'))

#query for data specifics and print
print(scope.query("WFMOutpre?"))
scope.write('CURVE?')
data = scope.read_raw()

headerlen = 2 + int(data[1])
header = data[:headerlen]
ADC_wave = data[headerlen:-1]
ADC_wave = np.array(unpack('%sB' % len(ADC_wave),ADC_wave))

Volts = (ADC_wave -yoff)* ymult  + yzero
Time = np.arange(0, xincr * len(Volts), xincr)

#plot waveforms
pylab.axes(axisbg='k')
#mem error can occur with many points
pylab.plot(Time[0:10000], Volts[0:10000], 'y', label=ch1_label, markerfacecolor='b', markersize=6)
pylab.grid(b=True, which='major', color='w', linestyle='--')
legend = pylab.legend(loc='upper right', shadow=True, frameon=True)
#legend.get_frame().set_facecolor('black')

pylab.ylim(min(Volts)-.5, max(Volts)+1)
pylab.xlabel('Time')
pylab.ylabel('Volts')
pylab.title('Oscope capture')
pylab.show()

# Run analysis -----------------------------------------------------

#obtain rise time info
print("obtaining rise time")
set_break = 0
for x in range(1, len(Volts)): #first marker over high level thresh
    if (Volts[x-1] > high_volt_trig):
        first_high_marker = x
        set_break = 1
    if (set_break == 1):
        break
set_break = 0
first_high_marker = 0
first_rise_marker = 0
for x in range(len(Volts), 1, -1): #first marker above low level thresh
    if (Volts[x-1] < low_volt_trig):
        first_rise_marker = x
        set_break = 1
    if (set_break == 1):
        break
rise_time = (first_high_marker - first_rise_marker)* xincr

#obtain noise info
print("analyzing noise")
voltage_adder = 0
for x in range(1, first_rise_marker):
    voltage_adder = voltage_adder + Volts[x-1]
low_level_noise = voltage_adder / first_rise_marker
voltage_adder = 0
for x in range(first_high_marker, len(Volts)):
    voltage_adder = voltage_adder + Volts[x-1]
high_level_noise = voltage_adder / (data_points - first_high_marker)

#obtain noise frequency info
print("plotting noise frequency")
signal_FFT = abs(np.fft.fft(Volts[0:10000]))
freqs = np.fft.fftfreq(len(Volts[0:10000]), Time[1]-Time[0])
pylab.plot(freqs, np.abs(signal_FFT))
pylab.xlim(0, max(freqs))
pylab.xlabel('frequency')
pylab.ylabel('amplitude')
pylab.title('Noise FFT')
pylab.show()