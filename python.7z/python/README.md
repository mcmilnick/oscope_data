# python notes

I use pycharm for my IDE. On windows, the proper libraries can not be installed through pycharm.
To get around this, I found the wheel files and manually installed them. I can not include them due
to sizing, but you can find them.

In addition, I also had to change the name of the wheel files to match my system. They really don't like installing
for 64bit windows so you have to find the right one in the repo and rename it amd64 as I have done.
This is strange since that should only be necessary for compilation, but these special wheel binaries
have needs. This lets the compiler know what's up.

I installed these libraries using pip.