# matlab notes

Here we have an analysis app in C#.
It is much more polished and easy to use, so it should speak for itself.