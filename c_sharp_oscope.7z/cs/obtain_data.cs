using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using System.Data;
using select_device;
using System.Threading;
using System.Text.RegularExpressions;
using System.Globalization;
using System.IO;
using System.Text;
using System.Net;
using NationalInstruments.VisaNS;

namespace obtain_data
{
    /// <summary>
    /// </summary>
    public class obtain_data : System.Windows.Forms.Form
    {
        private MessageBasedSession mbSession;
        private string lastResourceString = null;
        private OpenFileDialog openFileDialog1;
        private TabPage tabPage2;
        private Label label7;
        private TextBox ripple_Box;
        private TextBox fallBox;
        private TextBox riseBox;
        private Label label3;
        private Label label2;
        private Label label1;
        private Chart chart2;
        private TabPage tabPage1;
        private Label label6;
        private TextBox writeTextBox;
        private TextBox lastIOStatusTextBox;
        private TextBox readTextBox;
        private Button begintestbutton;
        private Chart chart1;
        private Label stringToWriteLabel;
        private Label lastIOStatusLabel;
        private Button openSessionButton;
        private Button closeSessionButton;
        private Button writeButton;
        private Button readButton;
        private TabControl tabControl1;
        private Label label9;
        private TextBox data_points_box;
        private Label label8;
        private TextBox trig_level_box;
        private TextBox trig_type_box;
        private TextBox trig_ch_box;
        private Label label11;
        private Label label10;
        private TextBox ch4_status_box;
        private TextBox ch3_status_box;
        private TextBox ch2_status_box;
        private TextBox ch1_status_box;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label12;
        private TextBox trig_mode_box;
        private TextBox rise_fall_trig_box;
        private Label label19;
        private Label label17;
        private Label label16;
        private TextBox rise_fall_ratio_box;
        private Label label21;
        private Button rise_time_button;
        private Button fall_time_button;
        private Button ripple_calc_button;
        private TextBox ripple_range_box;
        private Label label4;
        private System.ComponentModel.Container components = null;

        public obtain_data()
        {
            //
            // Required for Windows Form Designer support
            //
            InitializeComponent();
            SetupControlState(false);
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose( bool disposing )
        {
            if( disposing )
            {
                if(mbSession != null)
                {
                    mbSession.Dispose();
                }
                if (components != null) 
                {
                    components.Dispose();
                }
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code
        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea1 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend1 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series1 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea2 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend2 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series2 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(obtain_data));
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.ripple_range_box = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.ripple_calc_button = new System.Windows.Forms.Button();
            this.fall_time_button = new System.Windows.Forms.Button();
            this.rise_time_button = new System.Windows.Forms.Button();
            this.rise_fall_ratio_box = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.ripple_Box = new System.Windows.Forms.TextBox();
            this.fallBox = new System.Windows.Forms.TextBox();
            this.riseBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.chart2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.trig_mode_box = new System.Windows.Forms.TextBox();
            this.rise_fall_trig_box = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.ch4_status_box = new System.Windows.Forms.TextBox();
            this.ch3_status_box = new System.Windows.Forms.TextBox();
            this.ch2_status_box = new System.Windows.Forms.TextBox();
            this.ch1_status_box = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.trig_type_box = new System.Windows.Forms.TextBox();
            this.trig_ch_box = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.data_points_box = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.trig_level_box = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.writeTextBox = new System.Windows.Forms.TextBox();
            this.lastIOStatusTextBox = new System.Windows.Forms.TextBox();
            this.readTextBox = new System.Windows.Forms.TextBox();
            this.begintestbutton = new System.Windows.Forms.Button();
            this.chart1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.stringToWriteLabel = new System.Windows.Forms.Label();
            this.lastIOStatusLabel = new System.Windows.Forms.Label();
            this.openSessionButton = new System.Windows.Forms.Button();
            this.closeSessionButton = new System.Windows.Forms.Button();
            this.writeButton = new System.Windows.Forms.Button();
            this.readButton = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).BeginInit();
            this.tabPage1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).BeginInit();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.ripple_range_box);
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.ripple_calc_button);
            this.tabPage2.Controls.Add(this.fall_time_button);
            this.tabPage2.Controls.Add(this.rise_time_button);
            this.tabPage2.Controls.Add(this.rise_fall_ratio_box);
            this.tabPage2.Controls.Add(this.label21);
            this.tabPage2.Controls.Add(this.label7);
            this.tabPage2.Controls.Add(this.ripple_Box);
            this.tabPage2.Controls.Add(this.fallBox);
            this.tabPage2.Controls.Add(this.riseBox);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Controls.Add(this.label2);
            this.tabPage2.Controls.Add(this.label1);
            this.tabPage2.Controls.Add(this.chart2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(1114, 793);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // ripple_range_box
            // 
            this.ripple_range_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ripple_range_box.Location = new System.Drawing.Point(464, 24);
            this.ripple_range_box.Name = "ripple_range_box";
            this.ripple_range_box.Size = new System.Drawing.Size(126, 22);
            this.ripple_range_box.TabIndex = 46;
            this.ripple_range_box.Text = "0-100";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label4.Location = new System.Drawing.Point(464, 4);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(94, 17);
            this.label4.TabIndex = 45;
            this.label4.Text = "Ripple Range";
            // 
            // ripple_calc_button
            // 
            this.ripple_calc_button.Location = new System.Drawing.Point(621, 68);
            this.ripple_calc_button.Name = "ripple_calc_button";
            this.ripple_calc_button.Size = new System.Drawing.Size(116, 26);
            this.ripple_calc_button.TabIndex = 44;
            this.ripple_calc_button.Text = "Test Ripple";
            this.ripple_calc_button.Click += new System.EventHandler(this.ripple_calc_button_Click);
            // 
            // fall_time_button
            // 
            this.fall_time_button.Location = new System.Drawing.Point(271, 65);
            this.fall_time_button.Name = "fall_time_button";
            this.fall_time_button.Size = new System.Drawing.Size(116, 26);
            this.fall_time_button.TabIndex = 43;
            this.fall_time_button.Text = "Test Fall";
            this.fall_time_button.Click += new System.EventHandler(this.fall_time_button_Click);
            // 
            // rise_time_button
            // 
            this.rise_time_button.Location = new System.Drawing.Point(139, 65);
            this.rise_time_button.Name = "rise_time_button";
            this.rise_time_button.Size = new System.Drawing.Size(116, 26);
            this.rise_time_button.TabIndex = 42;
            this.rise_time_button.Text = "Test Rise";
            this.rise_time_button.Click += new System.EventHandler(this.rise_time_button_Click);
            // 
            // rise_fall_ratio_box
            // 
            this.rise_fall_ratio_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rise_fall_ratio_box.Location = new System.Drawing.Point(7, 24);
            this.rise_fall_ratio_box.Name = "rise_fall_ratio_box";
            this.rise_fall_ratio_box.Size = new System.Drawing.Size(126, 22);
            this.rise_fall_ratio_box.TabIndex = 41;
            this.rise_fall_ratio_box.Text = ".9";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 7.8F);
            this.label21.Location = new System.Drawing.Point(7, 4);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(99, 17);
            this.label21.TabIndex = 40;
            this.label21.Text = "Rise Fall Ratio";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label7.Location = new System.Drawing.Point(898, 28);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(116, 31);
            this.label7.TabIndex = 22;
            this.label7.Text = "Analysis";
            // 
            // ripple_Box
            // 
            this.ripple_Box.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ripple_Box.Location = new System.Drawing.Point(596, 24);
            this.ripple_Box.Multiline = true;
            this.ripple_Box.Name = "ripple_Box";
            this.ripple_Box.ReadOnly = true;
            this.ripple_Box.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.ripple_Box.Size = new System.Drawing.Size(175, 35);
            this.ripple_Box.TabIndex = 21;
            this.ripple_Box.TabStop = false;
            // 
            // fallBox
            // 
            this.fallBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.fallBox.Location = new System.Drawing.Point(271, 24);
            this.fallBox.Multiline = true;
            this.fallBox.Name = "fallBox";
            this.fallBox.ReadOnly = true;
            this.fallBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.fallBox.Size = new System.Drawing.Size(125, 35);
            this.fallBox.TabIndex = 18;
            this.fallBox.TabStop = false;
            this.fallBox.TextChanged += new System.EventHandler(this.fallBox_TextChanged);
            // 
            // riseBox
            // 
            this.riseBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.riseBox.Location = new System.Drawing.Point(139, 24);
            this.riseBox.Multiline = true;
            this.riseBox.Name = "riseBox";
            this.riseBox.ReadOnly = true;
            this.riseBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.riseBox.Size = new System.Drawing.Size(126, 35);
            this.riseBox.TabIndex = 17;
            this.riseBox.TabStop = false;
            this.riseBox.TextChanged += new System.EventHandler(this.riseBox_TextChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(658, 4);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 17);
            this.label3.TabIndex = 3;
            this.label3.Text = "Ripple";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(283, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 17);
            this.label2.TabIndex = 2;
            this.label2.Text = "Fall Time(s)";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(161, 4);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Rise Time(s)";
            // 
            // chart2
            // 
            chartArea1.Name = "ChartArea1";
            this.chart2.ChartAreas.Add(chartArea1);
            legend1.Name = "Legend1";
            this.chart2.Legends.Add(legend1);
            this.chart2.Location = new System.Drawing.Point(6, 136);
            this.chart2.Name = "chart2";
            series1.ChartArea = "ChartArea1";
            series1.Legend = "Legend1";
            series1.Name = "Series1";
            this.chart2.Series.Add(series1);
            this.chart2.Size = new System.Drawing.Size(1100, 654);
            this.chart2.TabIndex = 0;
            this.chart2.Text = "chart2";
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.trig_mode_box);
            this.tabPage1.Controls.Add(this.rise_fall_trig_box);
            this.tabPage1.Controls.Add(this.label19);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.ch4_status_box);
            this.tabPage1.Controls.Add(this.ch3_status_box);
            this.tabPage1.Controls.Add(this.ch2_status_box);
            this.tabPage1.Controls.Add(this.ch1_status_box);
            this.tabPage1.Controls.Add(this.label15);
            this.tabPage1.Controls.Add(this.label14);
            this.tabPage1.Controls.Add(this.label13);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.trig_type_box);
            this.tabPage1.Controls.Add(this.trig_ch_box);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.data_points_box);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.trig_level_box);
            this.tabPage1.Controls.Add(this.label6);
            this.tabPage1.Controls.Add(this.writeTextBox);
            this.tabPage1.Controls.Add(this.lastIOStatusTextBox);
            this.tabPage1.Controls.Add(this.readTextBox);
            this.tabPage1.Controls.Add(this.begintestbutton);
            this.tabPage1.Controls.Add(this.chart1);
            this.tabPage1.Controls.Add(this.stringToWriteLabel);
            this.tabPage1.Controls.Add(this.lastIOStatusLabel);
            this.tabPage1.Controls.Add(this.openSessionButton);
            this.tabPage1.Controls.Add(this.closeSessionButton);
            this.tabPage1.Controls.Add(this.writeButton);
            this.tabPage1.Controls.Add(this.readButton);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1114, 793);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "tabPage1";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // trig_mode_box
            // 
            this.trig_mode_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trig_mode_box.Location = new System.Drawing.Point(969, 114);
            this.trig_mode_box.Name = "trig_mode_box";
            this.trig_mode_box.Size = new System.Drawing.Size(126, 22);
            this.trig_mode_box.TabIndex = 41;
            this.trig_mode_box.Text = "NORMAL";
            // 
            // rise_fall_trig_box
            // 
            this.rise_fall_trig_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.rise_fall_trig_box.Location = new System.Drawing.Point(969, 170);
            this.rise_fall_trig_box.Name = "rise_fall_trig_box";
            this.rise_fall_trig_box.Size = new System.Drawing.Size(126, 22);
            this.rise_fall_trig_box.TabIndex = 40;
            this.rise_fall_trig_box.Text = "RISE";
            this.rise_fall_trig_box.TextChanged += new System.EventHandler(this.rise_fall_trig_box_TextChanged);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label19.Location = new System.Drawing.Point(965, 91);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(135, 20);
            this.label19.TabIndex = 39;
            this.label19.Text = "Trigger_Mode(V)";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label17.Location = new System.Drawing.Point(975, 147);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(109, 20);
            this.label17.TabIndex = 37;
            this.label17.Text = "Rise/Fall Trig";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label16.Location = new System.Drawing.Point(820, 91);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(130, 20);
            this.label16.TabIndex = 36;
            this.label16.Text = "Trigger Level(V)";
            // 
            // ch4_status_box
            // 
            this.ch4_status_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ch4_status_box.Location = new System.Drawing.Point(563, 170);
            this.ch4_status_box.Name = "ch4_status_box";
            this.ch4_status_box.Size = new System.Drawing.Size(102, 22);
            this.ch4_status_box.TabIndex = 34;
            this.ch4_status_box.Text = "OFF";
            // 
            // ch3_status_box
            // 
            this.ch3_status_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ch3_status_box.Location = new System.Drawing.Point(441, 170);
            this.ch3_status_box.Name = "ch3_status_box";
            this.ch3_status_box.Size = new System.Drawing.Size(102, 22);
            this.ch3_status_box.TabIndex = 33;
            this.ch3_status_box.Text = "OFF";
            // 
            // ch2_status_box
            // 
            this.ch2_status_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ch2_status_box.Location = new System.Drawing.Point(563, 114);
            this.ch2_status_box.Name = "ch2_status_box";
            this.ch2_status_box.Size = new System.Drawing.Size(102, 22);
            this.ch2_status_box.TabIndex = 32;
            this.ch2_status_box.Text = "OFF";
            // 
            // ch1_status_box
            // 
            this.ch1_status_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.ch1_status_box.Location = new System.Drawing.Point(441, 114);
            this.ch1_status_box.Name = "ch1_status_box";
            this.ch1_status_box.Size = new System.Drawing.Size(102, 22);
            this.ch1_status_box.TabIndex = 31;
            this.ch1_status_box.Text = "ON";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label15.Location = new System.Drawing.Point(437, 147);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(96, 20);
            this.label15.TabIndex = 30;
            this.label15.Text = "CH3 Status";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label14.Location = new System.Drawing.Point(437, 91);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(96, 20);
            this.label14.TabIndex = 29;
            this.label14.Text = "CH1 Status";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label13.Location = new System.Drawing.Point(559, 147);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(96, 20);
            this.label13.TabIndex = 28;
            this.label13.Text = "CH4 Status";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label12.Location = new System.Drawing.Point(559, 91);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(96, 20);
            this.label12.TabIndex = 27;
            this.label12.Text = "CH2 Status";
            // 
            // trig_type_box
            // 
            this.trig_type_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trig_type_box.Location = new System.Drawing.Point(824, 170);
            this.trig_type_box.Name = "trig_type_box";
            this.trig_type_box.Size = new System.Drawing.Size(126, 22);
            this.trig_type_box.TabIndex = 26;
            this.trig_type_box.Text = "EDGE";
            // 
            // trig_ch_box
            // 
            this.trig_ch_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trig_ch_box.Location = new System.Drawing.Point(680, 170);
            this.trig_ch_box.Name = "trig_ch_box";
            this.trig_ch_box.Size = new System.Drawing.Size(117, 22);
            this.trig_ch_box.TabIndex = 25;
            this.trig_ch_box.Text = "CH1";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label11.Location = new System.Drawing.Point(830, 147);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(103, 20);
            this.label11.TabIndex = 24;
            this.label11.Text = "Trigger Type";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label10.Location = new System.Drawing.Point(692, 147);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 20);
            this.label10.TabIndex = 23;
            this.label10.Text = "Trigger CH";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label9.Location = new System.Drawing.Point(692, 91);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(95, 20);
            this.label9.TabIndex = 22;
            this.label9.Text = "Data points";
            // 
            // data_points_box
            // 
            this.data_points_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.data_points_box.Location = new System.Drawing.Point(680, 114);
            this.data_points_box.Name = "data_points_box";
            this.data_points_box.Size = new System.Drawing.Size(117, 22);
            this.data_points_box.TabIndex = 21;
            this.data_points_box.Text = "100000";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F);
            this.label8.Location = new System.Drawing.Point(984, -198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(130, 20);
            this.label8.TabIndex = 20;
            this.label8.Text = "Trigger Level(V)";
            // 
            // trig_level_box
            // 
            this.trig_level_box.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.trig_level_box.Location = new System.Drawing.Point(824, 114);
            this.trig_level_box.Name = "trig_level_box";
            this.trig_level_box.Size = new System.Drawing.Size(126, 22);
            this.trig_level_box.TabIndex = 19;
            this.trig_level_box.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.label6.Location = new System.Drawing.Point(411, 26);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 31);
            this.label6.TabIndex = 18;
            this.label6.Text = "Data";
            // 
            // writeTextBox
            // 
            this.writeTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.writeTextBox.Location = new System.Drawing.Point(6, 60);
            this.writeTextBox.Name = "writeTextBox";
            this.writeTextBox.Size = new System.Drawing.Size(289, 22);
            this.writeTextBox.TabIndex = 2;
            this.writeTextBox.Text = "*IDN?\\n";
            // 
            // lastIOStatusTextBox
            // 
            this.lastIOStatusTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lastIOStatusTextBox.Location = new System.Drawing.Point(11, 765);
            this.lastIOStatusTextBox.Name = "lastIOStatusTextBox";
            this.lastIOStatusTextBox.ReadOnly = true;
            this.lastIOStatusTextBox.Size = new System.Drawing.Size(630, 22);
            this.lastIOStatusTextBox.TabIndex = 14;
            this.lastIOStatusTextBox.TabStop = false;
            // 
            // readTextBox
            // 
            this.readTextBox.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.readTextBox.Location = new System.Drawing.Point(564, 7);
            this.readTextBox.Multiline = true;
            this.readTextBox.Name = "readTextBox";
            this.readTextBox.ReadOnly = true;
            this.readTextBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.readTextBox.Size = new System.Drawing.Size(542, 75);
            this.readTextBox.TabIndex = 16;
            this.readTextBox.TabStop = false;
            this.readTextBox.TextChanged += new System.EventHandler(this.readTextBox_TextChanged);
            // 
            // begintestbutton
            // 
            this.begintestbutton.Location = new System.Drawing.Point(990, 761);
            this.begintestbutton.Name = "begintestbutton";
            this.begintestbutton.Size = new System.Drawing.Size(116, 26);
            this.begintestbutton.TabIndex = 15;
            this.begintestbutton.Text = "Begin_Test";
            this.begintestbutton.Click += new System.EventHandler(this.begintestbutton_Click);
            // 
            // chart1
            // 
            chartArea2.Name = "ChartArea1";
            this.chart1.ChartAreas.Add(chartArea2);
            legend2.Name = "Legend1";
            this.chart1.Legends.Add(legend2);
            this.chart1.Location = new System.Drawing.Point(11, 191);
            this.chart1.Name = "chart1";
            series2.ChartArea = "ChartArea1";
            series2.Legend = "Legend1";
            series2.Name = "Series1";
            this.chart1.Series.Add(series2);
            this.chart1.Size = new System.Drawing.Size(1095, 549);
            this.chart1.TabIndex = 17;
            this.chart1.Text = "chart1";
            // 
            // stringToWriteLabel
            // 
            this.stringToWriteLabel.Location = new System.Drawing.Point(8, 41);
            this.stringToWriteLabel.Name = "stringToWriteLabel";
            this.stringToWriteLabel.Size = new System.Drawing.Size(109, 16);
            this.stringToWriteLabel.TabIndex = 8;
            this.stringToWriteLabel.Text = "String to Write:";
            // 
            // lastIOStatusLabel
            // 
            this.lastIOStatusLabel.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.lastIOStatusLabel.Location = new System.Drawing.Point(8, 743);
            this.lastIOStatusLabel.Name = "lastIOStatusLabel";
            this.lastIOStatusLabel.Size = new System.Drawing.Size(139, 19);
            this.lastIOStatusLabel.TabIndex = 13;
            this.lastIOStatusLabel.Text = "Operation Status:";
            // 
            // openSessionButton
            // 
            this.openSessionButton.Location = new System.Drawing.Point(6, 6);
            this.openSessionButton.Name = "openSessionButton";
            this.openSessionButton.Size = new System.Drawing.Size(110, 25);
            this.openSessionButton.TabIndex = 0;
            this.openSessionButton.Text = "Open Session";
            this.openSessionButton.Click += new System.EventHandler(this.openSession_Click);
            // 
            // closeSessionButton
            // 
            this.closeSessionButton.Location = new System.Drawing.Point(122, 6);
            this.closeSessionButton.Name = "closeSessionButton";
            this.closeSessionButton.Size = new System.Drawing.Size(111, 25);
            this.closeSessionButton.TabIndex = 1;
            this.closeSessionButton.Text = "Close Session";
            this.closeSessionButton.Click += new System.EventHandler(this.closeSession_Click);
            // 
            // writeButton
            // 
            this.writeButton.Location = new System.Drawing.Point(11, 88);
            this.writeButton.Name = "writeButton";
            this.writeButton.Size = new System.Drawing.Size(110, 26);
            this.writeButton.TabIndex = 3;
            this.writeButton.Text = "Write";
            this.writeButton.Click += new System.EventHandler(this.write_Click);
            // 
            // readButton
            // 
            this.readButton.Location = new System.Drawing.Point(127, 88);
            this.readButton.Name = "readButton";
            this.readButton.Size = new System.Drawing.Size(111, 26);
            this.readButton.TabIndex = 4;
            this.readButton.Text = "Read";
            this.readButton.Click += new System.EventHandler(this.read_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Location = new System.Drawing.Point(1, -3);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1122, 822);
            this.tabControl1.TabIndex = 18;
            // 
            // obtain_data
            // 
            this.AutoScaleBaseSize = new System.Drawing.Size(6, 15);
            this.ClientSize = new System.Drawing.Size(1123, 821);
            this.Controls.Add(this.tabControl1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimumSize = new System.Drawing.Size(354, 365);
            this.Name = "obtain_data";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Oscope Capture";
            this.Load += new System.EventHandler(this.obtain_data_Load);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart2)).EndInit();
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.chart1)).EndInit();
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }
        #endregion

        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main() 
        {
            Application.Run(new obtain_data());
        }

        private void openSession_Click(object sender, System.EventArgs e)
        {
            using (select_device.select_device_name sr = new select_device.select_device_name())
            {
                if(lastResourceString != null)
                {
                    sr.ResourceName = lastResourceString;
                }
                DialogResult result = sr.ShowDialog(this);
                if(result == DialogResult.OK)
                {
                    lastResourceString = sr.ResourceName;
                    System.Windows.Forms.Cursor.Current = Cursors.WaitCursor;
                    try
                    {
                        mbSession = (MessageBasedSession)ResourceManager.GetLocalManager().Open(sr.ResourceName);
#if NETFX2_0
                        //For .NET Framework 2.0, use SynchronizeCallbacks to specify that the object 
                        //marshals callbacks across threads appropriately.
                        mbSession.SynchronizeCallbacks = true;
#else
                        //For .NET Framework 1.1, set SynchronizingObject to the Windows Form to specify 
                        //that the object marshals callbacks across threads appropriately.
                        mbSession.SynchronizingObject = this;
#endif
                        SetupControlState(true);
                    }
                    catch(InvalidCastException)
                    {
                        MessageBox.Show("Resource selected must be a message-based session");
                    }
                    catch(Exception exp)
                    {
                        MessageBox.Show(exp.Message);
                    }
                    finally
                    {
                        System.Windows.Forms.Cursor.Current = Cursors.Default;
                    }
                }
            }
        }

        private void closeSession_Click(object sender, System.EventArgs e)
        {
            SetupControlState(false);
            mbSession.Dispose();
        }

        private void write_Click(object sender, System.EventArgs e)
        {
            try
            {
                SetupWaitingControlState(false);
                string textToWrite = ReplaceCommonEscapeSequences(writeTextBox.Text);
                mbSession.Write(textToWrite);
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }

        private void read_Click(object sender, System.EventArgs e)
        {
            try
            {
                SetupWaitingControlState(false);
                string responseString = mbSession.ReadString();
                readTextBox.Text = InsertCommonEscapeSequences(responseString);
            }
            catch(Exception exp)
            {
                MessageBox.Show(exp.Message);
            }
        }
        
        private void SetupControlState(bool isSessionOpen)
        {
            openSessionButton.Enabled = !isSessionOpen;
            closeSessionButton.Enabled = isSessionOpen;
            writeButton.Enabled = isSessionOpen;
            readButton.Enabled = isSessionOpen;
            writeTextBox.Enabled = isSessionOpen;
            if(isSessionOpen)
            {
                writeTextBox.Focus();
            }
        }
        
        private void SetupWaitingControlState(bool operationIsInProgress)
        {
            writeButton.Enabled = !operationIsInProgress;
            readButton.Enabled = !operationIsInProgress;
        }

        private string ReplaceCommonEscapeSequences(string s)
        {
            return (s != null) ? s.Replace("\\n", "\n").Replace("\\r", "\r") : s;
        }

        private string InsertCommonEscapeSequences(string s)
        {
            return (s != null) ? s.Replace("\n", "\\n").Replace("\r", "\\r") : s;
        }

        System.Collections.Generic.List<collected_data> tek_data = new System.Collections.Generic.List<collected_data>();
        private void begintestbutton_Click(object sender, EventArgs e)
        {
            byte[] oscope_data = null;
            double voltage_high_level = double.Parse(trig_level_box.Text);
            double trig_percent = double.Parse(rise_fall_ratio_box.Text); ///Assumes a 90/10 rise/fall scheme
            double high_volt_trig = voltage_high_level * trig_percent;
            double low_volt_trig = voltage_high_level * (1 - trig_percent);
            double ymult, yzero, yoff, xincr;
            int data_points = int.Parse(data_points_box.Text);

            ///Data collection
            write_settings();
            begin_search(high_volt_trig);
            oscope_data = collect_data(data_points);

            ///retrieve the x and y scaling along with zero points
            ymult = double.Parse(mbSession.Query("WFMPRE:YMULT?"), CultureInfo.InvariantCulture.NumberFormat);
            yzero = double.Parse(mbSession.Query("WFMPRE:YZERO?"), CultureInfo.InvariantCulture.NumberFormat);
            yoff = double.Parse(mbSession.Query("WFMPRE:YOFF?"), CultureInfo.InvariantCulture.NumberFormat);
            xincr = double.Parse(mbSession.Query("WFMPRE:XINC?"), CultureInfo.InvariantCulture.NumberFormat);
            plot_waveform_data(oscope_data, ymult, yzero, yoff, xincr);

            double[] double_data = new double[oscope_data.Length];
            for (int i = 0; i < double_data.Length; i++)
            {
                double_data[i] = (double)oscope_data[i];
            }

            ///FFT calcs
            double[] FFTdata = new double[double_data.Length];
            Array.Copy(double_data, FFTdata, double_data.Length);
            calc_noise_freq(double_data, out FFTdata);
            plot_fft(FFTdata, data_points, xincr);

            ///Store for later use. We can also add subsequent waveforms
            tek_data.Add(new collected_data
            {
                waveform_data = double_data,
                FFT_data = FFTdata,
                ymult = ymult,
                yzero = yzero,
                yoff = yoff,
                xinc = xincr,
                volt_high_level = voltage_high_level,
                trigger_percent = trig_percent,
                high_volt_trigger = high_volt_trig,
                low_volt_trigger = low_volt_trig,
            });
        }

        private void write_settings()
        {
            ///Initial setup
            mbSession.Write("SELect:CH1 " + ch1_status_box.Text);
            mbSession.Write("SELect:CH2 " + ch2_status_box.Text);
            mbSession.Write("SELect:CH3 " + ch3_status_box.Text);
            mbSession.Write("SELect:CH4 " + ch4_status_box.Text);
            mbSession.Write("SELect:CONTROl CH1");
            ///If multiple channels are needed to control the trigger
            ///mbSession.Write("SELect:CONTROl {CH1|CH2}");

            ///Trigger setup - check pg1073 of programmers manual
            ///More must be done, but we don't want to start trigger yet.
            mbSession.Write("TRIGger:A:TYPe " + trig_type_box.Text);
            mbSession.Write("TRIGger:A:EDGE:SOUrce " + trig_ch_box.Text);
        }

        private void begin_search(double high_volt_trig)
        {
            ///General test info
            double used_to_trigger = Math.Round(high_volt_trig, 1);
            string textToWrite, triggerText;

            ///Configure and start Trigger Interrupts
            textToWrite = System.String.Format("TRIGger:A:LEVEL:" + trig_ch_box.Text + " {0}", used_to_trigger);
            mbSession.Write(textToWrite);
            mbSession.Write("TRIGger:A:EDGE:SLOpe " + rise_fall_trig_box.Text);
            mbSession.Write("TRIGger:A:MODE " + trig_mode_box.Text);

            Thread.Sleep(3000);

            ///Wait for trigger
            mbSession.Write("TRIGger:STATE?");
            triggerText = mbSession.ReadString();
            triggerText = Regex.Replace(triggerText, @"\t|\n|\r", "");
            while (triggerText != "TRIGGER")
            {
                Thread.Sleep(1000); ///Not needed but, must be less than the trigger reset timer.
                triggerText = mbSession.Query("TRIGger:STATE?");
                triggerText = Regex.Replace(triggerText, @"\t|\n|\r", "");
            }
            Thread.Sleep(2000);
        }

        private byte[] collect_data(int data_points)
        {
            String ch1_label, textToWrite, debug_info;
            byte[] oscope_data = null;

            ///Triggered - take data
            ///Channel labels
            ch1_label = mbSession.Query("CH1:LABel?");

            ///Control the region displayed of whats captured on the screen
            textToWrite = System.String.Format("DATA:STARt {0}", 1);
            mbSession.Write(textToWrite);
            textToWrite = System.String.Format("DATA:STOP {0}", data_points);
            mbSession.Write(textToWrite);
           
            ///Control the length recorded in samples/second
            textToWrite = System.String.Format("HORIZONTAL:RECORDLENGTH {0}", data_points);
            mbSession.Write(textToWrite);
            mbSession.DefaultBufferSize = data_points + 25;

            ///query for data specifics and print
            debug_info = mbSession.Query("WFMOutpre?");
            readTextBox.Text = debug_info;
            mbSession.Write("CURVE?");

            //Read data - check into referencing, pointers, marshalling blah blah.
            ///Thinking in C right now, but might need to do some smarter array passing.
            oscope_data = obtain_curve();
            return oscope_data;
        }

        private byte[] obtain_curve()
        {
            byte[] Block = null;
            byte[] WFMdata = null;
            int i = 0;

            mbSession.SendEndEnabled = true;
            mbSession.Write("curve?");
            Block = mbSession.ReadByteArray();
            if (Block[i++] == '#')
            {
                string NZDig = ASCIIEncoding.ASCII.GetString(Block, i++, 1);
                int count = int.Parse(NZDig);

                string Dig = ASCIIEncoding.ASCII.GetString(Block, i, count);
                int record = int.Parse(Dig);

                WFMdata = new byte[record];
                i += count;

                MemoryStream stream = new MemoryStream(Block, i, record);
                BinaryReader reader = new BinaryReader(stream);
                for (int j = 0; j < record; j++)
                {
                    WFMdata[j] = reader.ReadByte();
                }
            }
            return WFMdata;
        }

        private void plot_waveform_data(byte[] WFMdata, double ymult, double yzero, double yoff, double xincr)
        {
            double new_y;
            ///Scale all data accordingly and add to plot
            for (int i = 0; i < WFMdata.Length; i++)
            {
                new_y = ((WFMdata[i] - yoff) * ymult) + yzero;
                chart1.Series["Series1"].Points.AddXY((i * xincr), new_y);
            }
            
            ///Show plot lines, add labels, and rescale
            chart1.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            chart1.Titles.Add("Oscope Capture");
            chart1.ChartAreas[0].AxisX.Title = "Time";
            chart1.ChartAreas[0].AxisY.Title = "Voltage";
            chart1.ChartAreas[0].RecalculateAxesScale();
        }

        private void rise_time_button_Click(object sender, EventArgs e)
        {
            int first_high_marker = 0, first_rise_marker = 0;
            byte set_break = 0;
            double rise_time = 0;

            ///Find logic high trig
            Console.WriteLine("obtaining rise time");
            for (int i = 0; i < tek_data[0].waveform_data.Length; i++)
            {
                if (tek_data[0].waveform_data[i] >= tek_data[0].high_volt_trigger)
                {
                    first_high_marker = i;
                    set_break = 1;
                }
                if (set_break == 1)
                {
                    break;
                }
            }

            ///Find point where we first break past logic low trig
            set_break = 0;
            for (int i = first_high_marker; i >= 0; i--)
            {
                if (tek_data[0].waveform_data[i] <= tek_data[0].low_volt_trigger)
                {
                    first_rise_marker = i;
                    set_break = 1;
                }
                if (set_break == 1)
                {
                    break;
                }
            }
            ///calc rise time from time above logic low trig to time above logic high trig
            rise_time = (double)(first_high_marker - first_rise_marker) * tek_data[0].xinc;
            riseBox.Text = rise_time.ToString();
        }

        private void fall_time_button_Click(object sender, EventArgs e)
        {
            int first_fall_marker = 0, first_low_marker = 0;
            byte set_break = 0;
            double fall_time = 0;

            ///Find point where we first break past logic low trig
            set_break = 0;
            for (int i = 0; i < tek_data[0].waveform_data.Length; i++)
            {
                if (tek_data[0].waveform_data[i] <= tek_data[0].low_volt_trigger)
                {
                    first_low_marker = i;
                    set_break = 1;
                }
                if (set_break == 1)
                {
                    break;
                }
            }

            for (int i = first_low_marker; i >= 0; i--)
            {
                if(tek_data[0].waveform_data[i] > tek_data[0].high_volt_trigger)
                {
                    first_fall_marker = i;
                    set_break = 1;
                }
                if (set_break == 1)
                {
                    break;
                }
            }
            ///calc rise time from time above logic low trig to time above logic high trig
            fall_time = (double)(first_low_marker - first_fall_marker) * tek_data[0].xinc;
            riseBox.Text = fall_time.ToString();
        }

        private void ripple_calc_button_Click(object sender, EventArgs e)
        {
            string ripple_string= ripple_Box.Text;
            string delim = "-";
            string[] ripple_array = ripple_string.Split(delim.ToCharArray(), StringSplitOptions.RemoveEmptyEntries);
            int ripple_lower = int.Parse(ripple_array[0]);
            int ripple_upper = int.Parse(ripple_array[1]);
            double total_ripple = 0, volt_ave = 0;

            for (int i = ripple_lower; i <= ripple_upper; i++)
            {
                volt_ave += tek_data[0].waveform_data[i];
            }
            total_ripple = volt_ave;
            int num_samples = (ripple_upper - ripple_lower);
            volt_ave /= num_samples;
            total_ripple -= (num_samples * volt_ave); ///now only noise
            total_ripple /= num_samples;
            ripple_Box.Text = total_ripple.ToString();
        }

        private void calc_noise_freq(double[] WFMdata, out double[] FFTdata)
        {
            FFTdata = Lomont.LomontFFT.RealFFT(WFMdata, true);
            
        }

        public void plot_fft(double[] FFTdata, int data_points, double xincr)
        {
            double norm_factor = Double.Parse("1E300");
            double new_x;
            for (int i = 2; i < FFTdata.Length; i++)
            {
                new_x = i * ((1/xincr) / (FFTdata.Length*2));
                chart2.Series["Series1"].Points.AddXY(new_x, FFTdata[i]);
            }

            ///Show plot lines, add labels, and rescale
            chart2.Series["Series1"].ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.FastLine;
            chart2.Titles.Add("FFT data");
            chart2.ChartAreas[0].AxisX.Title = "Frequency";
            chart2.ChartAreas[0].AxisY.Title = "Amplitude";
            chart2.ChartAreas[0].AxisX.Maximum = data_points / 2;
            chart2.ChartAreas[0].AxisY.Maximum = 10;
            chart2.ChartAreas[0].AxisY.Minimum = 0;
            chart2.ChartAreas[0].RecalculateAxesScale();
        }

        private void riseBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void fallBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void readTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void high_noiseBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void rise_fall_trig_box_TextChanged(object sender, EventArgs e)
        {

        }

        private void obtain_data_Load(object sender, EventArgs e)
        {

        }
    }

    public class collected_data
    {
        public double[] waveform_data { get; set; }
        public double[] FFT_data { get; set; }
        public double ymult { get; set; }
        public double yzero { get; set; }
        public double yoff { get; set; }
        public double xinc { get; set; }
        public double volt_high_level { get; set; }
        public double trigger_percent { get; set; }
        public double high_volt_trigger { get; set; }
        public double low_volt_trigger { get; set; }
    }
}
